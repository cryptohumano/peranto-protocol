import{d as a}from"./dispatch-Cushl6QK.js";globalThis.window??=globalThis;chrome.runtime.onInstalled.addListener(()=>{console.log("[Aura] installed")});chrome.runtime.onMessage.addListener((o,n,r)=>(a(o).then(e=>r(e)).catch(e=>{r({ok:!1,error:e instanceof Error?e.message:String(e)})}),!0));
//# sourceMappingURL=service-worker.ts-zcKN_PIk.js.map
