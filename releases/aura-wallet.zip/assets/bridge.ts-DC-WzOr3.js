(function(){const t="aura-peranto";window.addEventListener("message",d=>{const e=d.data;!e||e.channel!==t||e.direction!=="inpage→cs"||chrome.runtime.sendMessage({type:"PROVIDER_REQUEST",id:e.id,method:e.method,params:e.params},r=>{const a=chrome.runtime.lastError;window.postMessage({channel:t,direction:"cs→inpage",id:e.id,result:!a&&r?.ok?r.data:void 0,error:a?a.message:r?.ok?void 0:r?.error??"Aura error"},"*")})});
//# sourceMappingURL=bridge.ts-DC-WzOr3.js.map
})()
